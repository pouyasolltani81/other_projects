from django.apps import AppConfig


class AuthmodelConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'AuthModel'
